package com.dxmaster.autoanswer;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * DX MASTER — Auto Answer (main screen)
 */
public class MainActivity extends Activity {

    private static final int BG          = 0xFF070B16;
    private static final int CARD        = 0xFF0E1426;
    private static final int CARD_BORDER = 0xFF1E2A4A;
    private static final int BLUE        = 0xFF2D9CFF;
    private static final int RED         = 0xFFFF2D55;
    private static final int WHITE       = 0xFFFFFFFF;
    private static final int TEXT        = 0xFFDCE3F5;
    private static final int MUTED       = 0xFF7C88A8;
    private static final int GREEN       = 0xFF3DDC84;

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP  = ViewGroup.LayoutParams.WRAP_CONTENT;

    private SharedPreferences prefs;

    private View statusDot;
    private GradientDrawable dotBg;
    private TextView statusText;
    private TextView statsText;
    private LinearLayout appsBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = DxConfig.prefs(this);

        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(34), dp(18), dp(34));
        root.setBackgroundColor(BG);

        buildHeader(root);
        buildStatusCard(root);
        buildSettingsCard(root);
        buildActionsCard(root);
        buildInfoCard(root);
        buildFooter(root);

        scroll.addView(root, new ViewGroup.LayoutParams(MATCH, WRAP));
        setContentView(scroll);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    // ------------------------------------------------------------ sections

    private void buildHeader(LinearLayout root) {
        TextView icon = new TextView(this);
        icon.setText("📞");
        icon.setTextSize(40);
        icon.setGravity(Gravity.CENTER);
        root.addView(icon, new LinearLayout.LayoutParams(MATCH, WRAP));

        SpannableString brand = new SpannableString("DX MASTER");
        brand.setSpan(new ForegroundColorSpan(RED), 0, 2, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        brand.setSpan(new ForegroundColorSpan(BLUE), 3, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        TextView title = new TextView(this);
        title.setText(brand);
        title.setTextSize(32);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.10f);
        root.addView(title, new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView sub = new TextView(this);
        sub.setText("SMART AUTO CALL ANSWER");
        sub.setTextColor(MUTED);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setLetterSpacing(0.18f);
        root.addView(sub, lp(MATCH, WRAP, 2));

        // neon divider (red -> blue)
        View line = new View(this);
        GradientDrawable lineBg = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT, new int[]{RED, BLUE});
        lineBg.setCornerRadius(dp(2));
        line.setBackground(lineBg);
        LinearLayout.LayoutParams llp = lp(dp(120), dp(3), 14);
        llp.gravity = Gravity.CENTER_HORIZONTAL;
        root.addView(line, llp);
    }

    private void buildStatusCard(LinearLayout root) {
        LinearLayout card = createCard();

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        statusDot = new View(this);
        dotBg = new GradientDrawable();
        dotBg.setShape(GradientDrawable.OVAL);
        dotBg.setColor(MUTED);
        statusDot.setBackground(dotBg);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(12), dp(12));
        dlp.setMarginEnd(dp(10));
        row.addView(statusDot, dlp);

        statusText = new TextView(this);
        statusText.setTextColor(TEXT);
        statusText.setTextSize(14);
        statusText.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(statusText, new LinearLayout.LayoutParams(0, WRAP, 1f));
        card.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));

        ObjectAnimator pulse = ObjectAnimator.ofFloat(statusDot, "alpha", 1f, 0.25f);
        pulse.setDuration(900);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();

        // master switch
        final Switch master = makeSwitch(prefs.getBoolean(DxConfig.K_ENABLED, true));
        master.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(DxConfig.K_ENABLED, checked).apply();
                refreshStatus();
            }
        });
        card.addView(makeRow("অটো আনসার চালু", "বন্ধ করলে কল নিজে ধরবে না", master), lp(MATCH, WRAP, 14));

        statsText = new TextView(this);
        statsText.setTextColor(MUTED);
        statsText.setTextSize(12.5f);
        statsText.setLineSpacing(dp(2), 1.1f);
        card.addView(statsText, lp(MATCH, WRAP, 12));

        root.addView(card, lp(MATCH, WRAP, 22));
    }

    private void buildSettingsCard(LinearLayout root) {
        LinearLayout card = createCard();

        card.addView(sectionTitle("⚙  সেটিংস"), new LinearLayout.LayoutParams(MATCH, WRAP));

        // delay
        final TextView delayLabel = new TextView(this);
        delayLabel.setTextColor(TEXT);
        delayLabel.setTextSize(13.5f);
        card.addView(delayLabel, lp(MATCH, WRAP, 14));

        int delay = prefs.getInt(DxConfig.K_DELAY, 0);
        delayLabel.setText(delayText(delay));

        SeekBar seek = new SeekBar(this);
        seek.setMax(10);
        seek.setProgress(delay);
        seek.setProgressTintList(ColorStateList.valueOf(BLUE));
        seek.setThumbTintList(ColorStateList.valueOf(RED));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                delayLabel.setText(delayText(progress));
                if (fromUser) prefs.edit().putInt(DxConfig.K_DELAY, progress).apply();
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                prefs.edit().putInt(DxConfig.K_DELAY, sb.getProgress()).apply();
            }
        });
        card.addView(seek, lp(MATCH, WRAP, 4));

        // video calls
        Switch video = makeSwitch(prefs.getBoolean(DxConfig.K_VIDEO, true));
        video.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(DxConfig.K_VIDEO, checked).apply();
            }
        });
        card.addView(makeRow("ভিডিও কলও রিসিভ করবে",
                "বন্ধ থাকলে শুধু অডিও কল ধরবে", video), lp(MATCH, WRAP, 16));

        // all apps
        Switch all = makeSwitch(prefs.getBoolean(DxConfig.K_ALL_APPS, true));
        all.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean(DxConfig.K_ALL_APPS, checked).apply();
                appsBox.setVisibility(checked ? View.GONE : View.VISIBLE);
            }
        });
        card.addView(makeRow("সব অ্যাপে কাজ করবে",
                "Messenger, WhatsApp, ডুয়াল/মাল্টি অ্যাপ সহ সব জায়গায়", all), lp(MATCH, WRAP, 16));

        // per-app list
        appsBox = new LinearLayout(this);
        appsBox.setOrientation(LinearLayout.VERTICAL);
        appsBox.setPadding(dp(8), dp(6), dp(8), dp(6));
        GradientDrawable boxBg = new GradientDrawable();
        boxBg.setColor(0xFF0A1020);
        boxBg.setCornerRadius(dp(12));
        boxBg.setStroke(dp(1), CARD_BORDER);
        appsBox.setBackground(boxBg);

        TextView appsTitle = new TextView(this);
        appsTitle.setText("যে অ্যাপে অটো আনসার হবে:");
        appsTitle.setTextColor(BLUE);
        appsTitle.setTextSize(12.5f);
        appsTitle.setTypeface(Typeface.DEFAULT_BOLD);
        appsTitle.setPadding(dp(4), dp(6), 0, dp(4));
        appsBox.addView(appsTitle);

        for (final DxConfig.Group g : DxConfig.GROUPS) {
            CheckBox cb = new CheckBox(this);
            cb.setText(g.label);
            cb.setTextColor(TEXT);
            cb.setTextSize(13.5f);
            cb.setButtonTintList(ColorStateList.valueOf(BLUE));
            cb.setChecked(prefs.getBoolean(DxConfig.K_GROUP + g.id, true));
            cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton b, boolean checked) {
                    prefs.edit().putBoolean(DxConfig.K_GROUP + g.id, checked).apply();
                }
            });
            appsBox.addView(cb, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        appsBox.setVisibility(prefs.getBoolean(DxConfig.K_ALL_APPS, true) ? View.GONE : View.VISIBLE);
        card.addView(appsBox, lp(MATCH, WRAP, 10));

        root.addView(card, lp(MATCH, WRAP, 16));
    }

    private void buildActionsCard(LinearLayout root) {
        LinearLayout card = createCard();
        card.addView(sectionTitle("🚀  শুরু করুন"), new LinearLayout.LayoutParams(MATCH, WRAP));

        Button access = createButton("Accessibility Settings খুলুন", true);
        access.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSafely(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS),
                        "তালিকা থেকে DX MASTER Auto Answer চালু করুন");
            }
        });
        card.addView(access, lp(MATCH, dp(52), 14));

        Button info = createButton("App Info (Restricted অনুমতি)", false);
        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                openSafely(i, "⋮ মেনু থেকে Allow restricted settings দিন");
            }
        });
        card.addView(info, lp(MATCH, dp(48), 10));

        Button battery = createButton("ব্যাটারি সেটিংস (Unrestricted করুন)", false);
        battery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSafely(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                        "DX MASTER কে Don't optimize করুন");
            }
        });
        card.addView(battery, lp(MATCH, dp(48), 10));

        root.addView(card, lp(MATCH, WRAP, 16));
    }

    private void buildInfoCard(LinearLayout root) {
        LinearLayout card = createCard();
        card.addView(sectionTitle("ℹ  কীভাবে কাজ করে"), new LinearLayout.LayoutParams(MATCH, WRAP));

        TextView body = new TextView(this);
        body.setText(
                "• Answer ও Decline বাটন একসাথে দেখা গেলেই শুধু Answer চাপে — তাই অন্য অ্যাপে Accept/OK চাপবে না\n"
                + "• কখনো Decline / End / Hang up চাপে না — কল আপনি না কাটলে কাটবে না\n"
                + "• চলমান কলের স্ক্রিনে (End call দেখা গেলে) কিছুই করে না\n"
                + "• অ্যাপ খোলা না রাখলেও সার্ভিস চলে; আপনি ফোনে স্বাভাবিকভাবে সব কিছু ব্যবহার করতে পারবেন\n"
                + "• Messenger, WhatsApp, ফোন কল ও কল নোটিফিকেশনে কাজ করার চেষ্টা করে\n\n"
                + "সব ফোন/অ্যাপ ভার্সনে ১০০% নিশ্চয়তা নেই। বাটনে লেখা বা description না থাকলে চিনতে পারবে না।");
        body.setTextColor(TEXT);
        body.setTextSize(12.5f);
        body.setLineSpacing(dp(3), 1.15f);
        card.addView(body, lp(MATCH, WRAP, 10));

        root.addView(card, lp(MATCH, WRAP, 16));
    }

    private void buildFooter(LinearLayout root) {
        TextView footer = new TextView(this);
        footer.setText("DX MASTER · Auto Answer v3.0");
        footer.setTextColor(MUTED);
        footer.setTextSize(11);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, lp(MATCH, WRAP, 22));
    }

    // ------------------------------------------------------------ status

    private void refreshStatus() {
        boolean serviceOn = isServiceEnabled();
        boolean enabled = prefs.getBoolean(DxConfig.K_ENABLED, true);

        if (serviceOn && enabled) {
            dotBg.setColor(GREEN);
            statusText.setText("সার্ভিস চালু — কল এলে নিজে ধরবে");
            statusText.setTextColor(GREEN);
        } else if (serviceOn) {
            dotBg.setColor(0xFFFFB020);
            statusText.setText("সার্ভিস চালু, কিন্তু অটো আনসার বন্ধ");
            statusText.setTextColor(0xFFFFB020);
        } else {
            dotBg.setColor(RED);
            statusText.setText("সার্ভিস বন্ধ — Accessibility থেকে চালু করুন");
            statusText.setTextColor(RED);
        }

        int total = prefs.getInt(DxConfig.K_TOTAL, 0);
        long last = prefs.getLong(DxConfig.K_LAST_TIME, 0L);
        String lastApp = prefs.getString(DxConfig.K_LAST_APP, "");
        StringBuilder sb = new StringBuilder();
        sb.append("মোট অটো রিসিভ: ").append(total);
        if (last > 0) {
            String when = new SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(new Date(last));
            sb.append("\nশেষ কল: ").append(when);
            if (lastApp != null && !lastApp.isEmpty()) sb.append("  (").append(lastApp).append(")");
        }
        statsText.setText(sb.toString());
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName cn = new ComponentName(this, AnswerAccessibilityService.class);
        String full = cn.flattenToString();
        String shortName = cn.flattenToShortString();
        for (String s : enabled.split(":")) {
            if (s.equalsIgnoreCase(full) || s.equalsIgnoreCase(shortName)) return true;
        }
        return false;
    }

    private void openSafely(Intent intent, String hint) {
        try {
            startActivity(intent);
            Toast.makeText(this, hint, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Settings খোলা যায়নি", Toast.LENGTH_SHORT).show();
        }
    }

    private String delayText(int sec) {
        if (sec <= 0) return "⏱  রিসিভ করার আগে অপেক্ষা: সাথে সাথে";
        return "⏱  রিসিভ করার আগে অপেক্ষা: " + sec + " সেকেন্ড";
    }

    // ------------------------------------------------------------ UI helpers

    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(CARD);
        bg.setCornerRadius(dp(18));
        bg.setStroke(dp(1), CARD_BORDER);
        card.setBackground(bg);
        return card;
    }

    private TextView sectionTitle(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(WHITE);
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout makeRow(String title, String subtitle, Switch sw) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(WHITE);
        t.setTextSize(14.5f);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        texts.addView(t);

        TextView s = new TextView(this);
        s.setText(subtitle);
        s.setTextColor(MUTED);
        s.setTextSize(11.5f);
        texts.addView(s);

        row.addView(texts, new LinearLayout.LayoutParams(0, WRAP, 1f));
        row.addView(sw, new LinearLayout.LayoutParams(WRAP, WRAP));
        return row;
    }

    private Switch makeSwitch(boolean checked) {
        Switch sw = new Switch(this);
        int[][] states = new int[][]{
                new int[]{android.R.attr.state_checked},
                new int[]{}
        };
        sw.setThumbTintList(new ColorStateList(states, new int[]{BLUE, MUTED}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{0x662D9CFF, 0x33FFFFFF}));
        sw.setChecked(checked);
        return sw;
    }

    private Button createButton(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(primary ? 15 : 13.5f);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setStateListAnimator(null);

        GradientDrawable bg;
        if (primary) {
            bg = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{RED, BLUE});
            b.setTextColor(WHITE);
        } else {
            bg = new GradientDrawable();
            bg.setColor(0xFF111A33);
            bg.setStroke(dp(1), BLUE);
            b.setTextColor(BLUE);
        }
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(topDp);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
