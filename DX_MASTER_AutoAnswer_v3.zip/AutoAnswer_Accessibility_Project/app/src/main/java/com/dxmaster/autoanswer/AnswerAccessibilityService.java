package com.dxmaster.autoanswer;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.SharedPreferences;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.List;
import java.util.Locale;

/**
 * DX MASTER Auto Answer Service
 *
 * Rules (so it never disturbs normal phone use and never cuts a call):
 *  1. It only acts on a window that shows an "Answer" button AND a "Decline" button together
 *     (that is what an incoming-call screen / call notification looks like).
 *  2. It never presses Decline / End / Hang up. It only presses Answer.
 *  3. Windows that already show "End call" / "Hang up" (a running call) are ignored.
 */
public class AnswerAccessibilityService extends AccessibilityService {

    private static final long SCAN_MIN_INTERVAL_MS = 250;
    private static final long LOCKOUT_AFTER_ANSWER_MS = 6000;
    private static final long LOCKOUT_AFTER_FAIL_MS = 1200;
    private static final int MAX_NODES = 500;
    private static final int MAX_DEPTH = 28;

    private static final int NONE = 0;
    private static final int ANSWER = 1;
    private static final int DECLINE = 2;
    private static final int END = 3;

    private static final String[] ANSWER_EXACT = {
            "answer", "accept", "answer call", "accept call", "pick up", "receive",
            "answer audio call", "accept audio call", "answer video call", "accept video call",
            "accept voice call", "answer voice call",
            "উত্তর", "উত্তর দিন", "রিসিভ", "রিসিভ করুন", "গ্রহণ", "গ্রহণ করুন",
            "কল গ্রহণ", "কল উত্তর", "কল রিসিভ"
    };

    private static final String[] ANSWER_PARTIAL = {
            "answer", "accept", "উত্তর", "রিসিভ", "গ্রহণ"
    };

    // words that make an "answer-looking" label unsafe (e.g. "End & accept", "Remind me")
    private static final String[] ANSWER_BLOCK = {
            "end", "hold", "&", "later", "remind", "reply", "message", "টেক্সট", "মেসেজ"
    };

    private static final String[] DECLINE_KEYS = {
            "decline", "reject", "প্রত্যাখ্যান", "ডিক্লাইন", "রিজেক্ট", "কেটে", "কাটুন"
    };

    private static final String[] END_KEYS = {
            "end call", "hang up", "hangup", "end &", "end and", "কল শেষ"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;

    private long lastScan = 0L;
    private long lockUntil = 0L;
    private boolean pending = false;
    private boolean trailingScheduled = false;

    private static final class Candidate {
        AccessibilityNodeInfo node;
        String pkg;
    }

    private static final class Scan {
        AccessibilityNodeInfo answer;
        boolean decline;
        boolean inCall;
        int count;
    }

    private final Runnable trailingScan = new Runnable() {
        @Override
        public void run() {
            trailingScheduled = false;
            runScan();
        }
    };

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        prefs = DxConfig.prefs(this);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        int type = event.getEventType();
        if (type != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                && type != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                && type != AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            return;
        }

        if (prefs == null) prefs = DxConfig.prefs(this);
        if (!prefs.getBoolean(DxConfig.K_ENABLED, true)) return;

        long now = SystemClock.uptimeMillis();
        if (pending || now < lockUntil) return;

        if (now - lastScan < SCAN_MIN_INTERVAL_MS) {
            // make sure the last event of a burst is still checked
            if (!trailingScheduled) {
                trailingScheduled = true;
                handler.postDelayed(trailingScan, SCAN_MIN_INTERVAL_MS);
            }
            return;
        }
        runScan();
    }

    private void runScan() {
        if (prefs == null) prefs = DxConfig.prefs(this);
        if (!prefs.getBoolean(DxConfig.K_ENABLED, true)) return;

        long now = SystemClock.uptimeMillis();
        if (pending || now < lockUntil) return;
        lastScan = now;

        Candidate c = findCandidate();
        if (c == null) return;

        int delaySec = prefs.getInt(DxConfig.K_DELAY, 0);
        if (delaySec <= 0) {
            attemptAnswer();
        } else {
            pending = true;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    pending = false;
                    attemptAnswer();
                }
            }, delaySec * 1000L);
        }
    }

    private void attemptAnswer() {
        if (prefs == null) prefs = DxConfig.prefs(this);
        if (!prefs.getBoolean(DxConfig.K_ENABLED, true)) return;

        Candidate c = findCandidate();   // fresh nodes (caller may have hung up meanwhile)
        if (c == null) return;

        boolean ok = performAnswer(c.node);
        long now = SystemClock.uptimeMillis();
        if (ok) {
            lockUntil = now + LOCKOUT_AFTER_ANSWER_MS;
            recordAnswer(c.pkg);
        } else {
            lockUntil = now + LOCKOUT_AFTER_FAIL_MS;
        }
    }

    private void recordAnswer(String pkg) {
        int total = prefs.getInt(DxConfig.K_TOTAL, 0) + 1;
        prefs.edit()
                .putInt(DxConfig.K_TOTAL, total)
                .putLong(DxConfig.K_LAST_TIME, System.currentTimeMillis())
                .putString(DxConfig.K_LAST_APP, pkg == null ? "" : pkg)
                .apply();
    }

    // ---------------------------------------------------------------- detection

    private Candidate findCandidate() {
        boolean allowVideo = prefs.getBoolean(DxConfig.K_VIDEO, true);

        List<AccessibilityWindowInfo> windows = null;
        try {
            windows = getWindows();
        } catch (Exception ignored) {
        }

        if (windows != null && !windows.isEmpty()) {
            for (AccessibilityWindowInfo w : windows) {
                if (w == null) continue;
                Candidate c = scanRoot(w.getRoot(), allowVideo);
                if (c != null) return c;
            }
            return null;
        }
        return scanRoot(getRootInActiveWindow(), allowVideo);
    }

    private Candidate scanRoot(AccessibilityNodeInfo root, boolean allowVideo) {
        if (root == null) return null;

        CharSequence pkgCs = root.getPackageName();
        String pkg = pkgCs == null ? null : pkgCs.toString();
        if (pkg == null || pkg.equals(getPackageName())) return null;
        if (!DxConfig.isPackageAllowed(prefs, pkg)) return null;

        Scan s = new Scan();
        scan(root, s, 0, allowVideo);

        // incoming call screen = Answer + Decline together, and no running-call "End call" button
        if (s.answer != null && s.decline && !s.inCall) {
            Candidate c = new Candidate();
            c.node = s.answer;
            c.pkg = pkg;
            return c;
        }
        return null;
    }

    private void scan(AccessibilityNodeInfo node, Scan s, int depth, boolean allowVideo) {
        if (node == null || s.count >= MAX_NODES || depth > MAX_DEPTH) return;
        s.count++;

        int kind = NONE;
        int k1 = classify(node.getText(), allowVideo);
        int k2 = classify(node.getContentDescription(), allowVideo);
        if (k1 == END || k2 == END) {
            kind = END;
        } else if (k1 == DECLINE || k2 == DECLINE) {
            kind = DECLINE;
        } else if (k1 == ANSWER || k2 == ANSWER) {
            kind = ANSWER;
        }

        if (kind == END) {
            s.inCall = true;
        } else if (kind == DECLINE) {
            s.decline = true;
        } else if (kind == ANSWER && s.answer == null) {
            s.answer = node;
        }

        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) scan(child, s, depth + 1, allowVideo);
        }
    }

    private static int classify(CharSequence cs, boolean allowVideo) {
        if (cs == null) return NONE;
        String s = cs.toString().toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty() || s.length() > 40) return NONE;

        if (containsAny(s, END_KEYS)) return END;
        if (containsAny(s, DECLINE_KEYS)) return DECLINE;
        if (isAnswerLabel(s, allowVideo)) return ANSWER;
        return NONE;
    }

    private static boolean isAnswerLabel(String s, boolean allowVideo) {
        if (!allowVideo && (s.contains("video") || s.contains("ভিডিও"))) return false;
        if (containsAny(s, ANSWER_BLOCK)) return false;

        for (String key : ANSWER_EXACT) {
            if (s.equals(key)) return true;
        }
        if (s.length() <= 30) {
            return containsAny(s, ANSWER_PARTIAL);
        }
        return false;
    }

    private static boolean containsAny(String s, String[] keys) {
        for (String k : keys) {
            if (s.contains(k)) return true;
        }
        return false;
    }

    // ---------------------------------------------------------------- action

    private boolean performAnswer(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        for (int i = 0; i < 4 && cur != null; i++) {
            if (cur.isClickable() && cur.isEnabled()
                    && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                return true;
            }
            cur = cur.getParent();
        }
        return tapCenter(node);
    }

    private boolean tapCenter(AccessibilityNodeInfo node) {
        if (node == null || !node.isVisibleToUser()) return false;
        Rect r = new Rect();
        node.getBoundsInScreen(r);
        if (r.isEmpty()) return false;

        Path p = new Path();
        p.moveTo(r.centerX(), r.centerY());
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(p, 0, 60);
        GestureDescription g = new GestureDescription.Builder().addStroke(stroke).build();
        return dispatchGesture(g, null, null);
    }

    @Override
    public void onInterrupt() {
        // required
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
