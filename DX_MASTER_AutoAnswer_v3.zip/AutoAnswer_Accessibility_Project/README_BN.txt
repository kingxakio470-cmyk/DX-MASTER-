DX MASTER — Auto Answer v3.0
============================

কী কী আছে
---------
• নতুন ডার্ক নিয়ন (লাল-নীল) ডিজাইন
• অটো আনসার চালু/বন্ধ সুইচ
• রিসিভ করার আগে অপেক্ষা (০–১০ সেকেন্ড)
• ভিডিও কল রিসিভ চালু/বন্ধ
• সব অ্যাপে কাজ, অথবা বেছে নেওয়া অ্যাপে (ফোন, Messenger, Facebook, WhatsApp, Telegram, IMO, Instagram, Viber, Meet, ডুয়াল/ক্লোন অ্যাপ)
• মোট অটো রিসিভ ও শেষ কলের তথ্য
• সার্ভিস চালু আছে কি না লাইভ স্ট্যাটাস
• নিরাপদ: Answer ও Decline একসাথে দেখা গেলেই শুধু Answer চাপে
• কখনো Decline / End / Hang up চাপে না
• চলমান কলের স্ক্রিনে কিছুই করে না

APK বানানো (GitHub)
-------------------
১. DX_MASTER_AutoAnswer_v3.zip রিপোজিটরিতে আপলোড করুন
২. .github/workflows/build.yml ফাইল নতুন কোড দিয়ে বদলান
৩. Actions থেকে APK ডাউনলোড করুন

ইনস্টলের পর
------------
১. অ্যাপ খুলুন → Accessibility Settings → DX MASTER Auto Answer চালু করুন
২. ধূসর থাকলে App Info → ⋮ → Allow restricted settings
৩. ব্যাটারি সেটিংসে Unrestricted করুন
